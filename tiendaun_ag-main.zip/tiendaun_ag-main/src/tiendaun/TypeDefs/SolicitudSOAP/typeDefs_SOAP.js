export const soapTypeDef = `
type emails {
    email:String!
}
  `;

export const soapQueries = `
      allEmails: [emails]
  `;
