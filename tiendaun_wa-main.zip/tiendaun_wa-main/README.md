# tiendaUn_wa
# Run the following commands
# cd tiendaUn_wa
# npm install 
# npm run dev

