import { useState } from "react";
import tiendaUnLogo from '../../assets/images/logos/LogoMorado.png';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useMutation, gql } from "@apollo/client";
type CarritoProp = {
    title?: string
   
}





export const Carrito = ({ }: CarritoProp) => {

     return(
        <div className="center">
              
               <h1>Carrito</h1>
               
               
             
                   
            
      </div>
     
)     

     }